import pymysql
from config import host, user, password, db_name


# Обработка исключений
try:
    # Подключение к базе данных при помощи connect()
    connection = pymysql.connect(
       host=host,
       port=3306,
       user=user,
       password=password,
       database=db_name,
       cursorclass=pymysql.cursors.DictCursor
    )
    print('Successfully connected...')
    print("#" * 20)


except Exception as ex:
    print('Connection refused...')
    print(ex)


def con():
    return None