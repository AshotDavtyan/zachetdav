from connDB import con
import cgi
import html

form = cgi.FieldStorage()
email = form.getfirst("email", "пустое значение")
passw = form.getfirst("pass", "пустое значение")

email = html.escape(email)
passw = html.escape(passw)

# Проверяем, есть ли пользователь с таким email и паролем в базе данных
db = con()
cursor = db.cursor()
sql = "SELECT * FROM employees WHERE email=%s AND password=%s"
val = (email, passw)
cursor.execute(sql, val)
result = cursor.fetchone()

if result:
    # Если пользователь найден, перенаправляем на страницу с его данными
    print("Location: /employee_info.html\n")
else:
    # Иначе выводим сообщение об ошибке
    print("Content-type: text/html\n")
    print("""<!DOCTYPE HTML>
           <html>
           <head>
               <meta charset="utf-8">
               <title>Ошибка авторизации</title>
               <link rel="stylesheet" href="../style.css">
           </head>
           <body id='employee'>""")
    print("<h4>Ошибка авторизации</h4>")
    print("<p>Пользователь не найден. Проверьте правильность введенных данных.</p>")

# Закрываем соединение с базой данных
cursor.close()
db.close()
